/************************************************************************/
/* Copyright (C)  SSE@USTC, 2014-2015                                   */
/*                                                                      */
/*  FILE NAME             :  menu.h                                     */
/*  PRINCIPAL AUTHOR      :  liujiaqi                                   */
/*  STUDENT NUMBER        :  JG14225082                                 */
/*  SUBSYSTEM NAME        :  menu                                       */
/*  MODULE NAME           :  menu                                       */
/*  LANGUAGE              :  C                                          */
/*  TARGET ENVIRONMENT    :  ANY                                        */
/*  DATE OF FIRST RELEASE :  2014/09/30                                 */
/*  DESCRIPTION           :  interface of menu                          */
/************************************************************************/

/*
 * Revision log:
 *
 * Created by liujiaqi, 2014/09/30
 *
*/

#include<stdlib.h>

#define SUCCESS 1
#define FAILURE -1

typedef struct LinkTable 
{

}tLinkTable;
/*
 * Data Node Type
 */
typedef struct DataNode 
{

}tDataNode;
/*
 * Search for the Cmd
 */
tDataNode *SearchCmd(tLinkTable * pLinkTable, char *cmd);
/*
 * Print All Cmd
 */
int ShowAllCmd(tLinkTable * pLinkTable);
/*
 * Creat a Menu
 */
int CreatMenu(tLinkTable * pLinkTable, tDataNode* data, int n);
/*
 * Run the Menu
 */
int RunMenu(tLinkTable * pLinkTable);
/*
 * Print All Cmd
 */
int Help(tLinkTable* pLinkTable);
/*
 * Add a Cmd to Menu
 */
int Add(tLinkTable* pLinkTable);
/*
 * Delete a Cmd from Menu
 */
int Delete(tLinkTable* pLinkTable);
/*
 * Quit Menu
 */
int Quit(tLinkTable* pLinkTable);
